package com.Ibase.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.Ibase.model.IbaseProduct;
import com.Ibase.service.IbaseProductService;

@RestController
@RequestMapping("/api/products")
public class IbaseProductsControllers {
	@Autowired
	IbaseProductService ibaseProductService;
	
	@GetMapping
	public ResponseEntity<List<IbaseProduct>> getAllProducts() {
		return ibaseProductService.getAllProducts();
	}
	
	@PostMapping
	public ResponseEntity<IbaseProduct> createProduct(@RequestBody IbaseProduct product) {
		return ibaseProductService.createProduct(product);
	}
	
	@GetMapping("/{productId}")
	public ResponseEntity<Optional<IbaseProduct>> getProductById(@PathVariable String productId) {
		return ibaseProductService.getProductById(productId);
	}
	
	@DeleteMapping("/{productId}")
	public ResponseEntity<String> deleteProductById(@PathVariable String productId) {
		return ibaseProductService.deleteProductById(productId);
	}
	
	@PutMapping("/{productId}")
	public ResponseEntity<IbaseProduct> updateProductById(@RequestBody IbaseProduct updateProduct, @PathVariable String productId) {
		return ibaseProductService.updateProductById(updateProduct,productId);
	}
	
	@GetMapping(params="shopId")
	public ResponseEntity<List<IbaseProduct>> getProductByShopId(@RequestParam String shopId) {
		return  ibaseProductService.getProductByShopId(shopId);
	}
	
	@GetMapping( params="title")
	public ResponseEntity<List<IbaseProduct>> getProductByTitle(@RequestParam String title){
		return ibaseProductService.getProductByTitle(title);
	}
	
	@GetMapping( params= {"minPrice","maxPrice"} )
	public ResponseEntity<List<IbaseProduct>> getProductByPriceBB(@RequestParam double minPrice , double maxPrice ){
		return ibaseProductService.getProductByPriceBB(minPrice, maxPrice);
	}

}
