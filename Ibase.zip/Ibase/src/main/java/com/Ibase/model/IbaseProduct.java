
package com.Ibase.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="Product")
public class IbaseProduct {
	@Id
	private String productId;
	private String shopId;
	private String title;
	private String description;
	private double lastPrice;
	private double sellPrice;
	private int warranty;
	private double rating;
	private int stock;
	private String brand;
	private String model;
	
	

	
	public IbaseProduct(String productId, String shopId, String title, String description, double lastPrice,
			double sellPrice, int warranty, double rating, int stock, String brand, String model) {
		super();
		this.productId = productId;
		this.shopId = shopId;
		this.title = title;
		this.description = description;
		this.lastPrice = lastPrice;
		this.sellPrice = sellPrice;
		this.warranty = warranty;
		this.rating = rating;
		this.stock = stock;
		this.brand = brand;
		this.model = model;
	}


	public String getproductId() {
		return productId;
	}


	public void setproductId(String productId) {
		this.productId = productId;
	}


	public String getshopId() {
		return shopId;
	}


	public void setshopId(String shopId) {
		this.shopId = shopId;
	}


	public String getTitle() {
		return title;
	}


	public void setTitle(String title) {
		this.title = title;
	}


	public String getDescription() {
		return description;
	}


	public void setDescription(String description) {
		this.description = description;
	}


	public double getLastPrice() {
		return lastPrice;
	}


	public void setLastPrice(double lastPrice) {
		this.lastPrice = lastPrice;
	}


	public double getSellPrice() {
		return sellPrice;
	}


	public void setSellPrice(double sellPrice) {
		this.sellPrice = sellPrice;
	}


	public int getWarranty() {
		return warranty;
	}


	public void setWarranty(int warranty) {
		this.warranty = warranty;
	}


	public double getRating() {
		return rating;
	}


	public void setRating(double rating) {
		this.rating = rating;
	}


	public int getStock() {
		return stock;
	}


	public void setStock(int stock) {
		this.stock = stock;
	}


	public String getBrand() {
		return brand;
	}


	public void setBrand(String brand) {
		this.brand = brand;
	}


	public String getModel() {
		return model;
	}


	public void setModel(String model) {
		this.model = model;
	}


	@Override
	public String toString() {
		return "IbaseProduct [productId=" + productId + ", shopId=" + shopId + ", title=" + title + ", description="
				+ description + ", lastPrice=" + lastPrice + ", sellPrice=" + sellPrice + ", warranty=" + warranty
				+ ", rating=" + rating + ", stock=" + stock + ", brand=" + brand + ", model=" + model + "]";
	}


}
